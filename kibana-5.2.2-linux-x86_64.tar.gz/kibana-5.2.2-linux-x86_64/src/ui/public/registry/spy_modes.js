import uiRegistry from 'ui/registry/_registry';
export default uiRegistry({
  name: 'spyModes',
  index: ['name'],
  order: ['order']
});
