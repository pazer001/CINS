import { kbnUrlDirective } from './kbn_href';

kbnUrlDirective('kbnSrc');
